import { NextResponse } from "next/server";

export const runtime = "nodejs";

/**
 * Queues a short GIF render via your queue endpoint.
 * Body: { compositionId: "festival-intro", inputProps: {...}, encoding: {...}, quality: "gif" }
 */
export async function POST(req: Request) {
  try {
    const body = await req.json();
    const payload = {
      ...body,
      quality: "gif",
      container: "gif",
      codec: "gif",
      encoding: {
        width: body?.encoding?.width ?? 540,
        height: body?.encoding?.height ?? 960,
        fps: body?.encoding?.fps ?? 12,
        durationSeconds: body?.encoding?.durationSeconds ?? 3.5,
      },
      outExt: "gif",
    };

    const r = await fetch(`${process.env.NEXT_PUBLIC_BASE_URL}/api/lambda/queue`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload),
    });

    const j = await r.json();
    if (!r.ok) return NextResponse.json({ error: j?.error || "Queue failed" }, { status: 500 });
    return NextResponse.json(j);
  } catch (e: any) {
    return NextResponse.json({ error: e?.message || "Failed" }, { status: 500 });
  }
}
