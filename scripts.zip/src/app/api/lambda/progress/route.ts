import { NextResponse } from "next/server";
import { getRenderProgress, getFunctions, type AwsRegion } from "@remotion/lambda/client";
import { S3Client, HeadObjectCommand } from "@aws-sdk/client-s3";
import { makeLimiter, limitOrThrow, getIP } from "@/lib/ops";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

const perIpProgressLimiter = makeLimiter(Number(process.env.PROGRESS_PER_IP_PER_MIN || 30), 60);

export async function GET(req: Request) {
  const { searchParams } = new URL(req.url);
  const renderId = searchParams.get("renderId");
  const bucketName = searchParams.get("bucketName");
  const fnFromClient = searchParams.get("functionName");
  const region = (process.env.REMOTION_REGION as AwsRegion) || ("ap-south-1" as AwsRegion);

  if (!renderId || !bucketName) {
    return NextResponse.json({ error: "Missing renderId/bucketName" }, { status: 400 });
  }

  try {
    // Per-IP limit on polling
    const ip = getIP(req as any);
    await limitOrThrow(perIpProgressLimiter, `prog:${ip}`, "Too many progress checks.");

    const functionName =
      fnFromClient ||
      process.env.REMOTION_FUNCTION_NAME ||
      (await (async () => {
        const fns = await getFunctions({ region, compatibleOnly: true });
        return fns[0]?.functionName;
      })());

    if (!functionName) {
      return NextResponse.json({ error: "Cannot resolve functionName" }, { status: 500 });
    }

    const progress = await getRenderProgress({ region, renderId, bucketName, functionName });
    return NextResponse.json(progress);
  } catch (e: any) {
    const msg = String(e?.message || "");

    if (msg.includes("Invalid JSON")) {
      return NextResponse.json({ done: false, overallProgress: 0, errors: [] });
    }

    // Handle stills: probe S3 for the image if Lambda progress can't merge
    if (msg.includes("Cannot merge stills")) {
      try {
        const s3 = new S3Client({ region });
        for (const ext of ["png", "jpeg"]) {
          const key = `renders/${renderId}/out.${ext}`;
          try {
            await s3.send(new HeadObjectCommand({ Bucket: bucketName!, Key: key }));
            return NextResponse.json({ done: true, outKey: key, errors: [] });
          } catch {
            // try next ext
          }
        }
        return NextResponse.json({ done: false, overallProgress: 0, errors: [] });
      } catch (e2) {
        // fall through
      }
    }

    // Signal throttles to client so it backs off (you already handle 429)
    const status = msg.includes("Rate") ? 429 : 500;
    console.error("PROGRESS ERROR", e);
    return NextResponse.json({ error: msg || "Progress failed" }, { status });
  }
}
