/**
 * Builder: colorful UI + new features (public link, owner fields, festival preselect,
 * payments (Admin SDK backend), export, router-free navigation).
 */
"use client";
export const dynamic = "force-dynamic";

import Script from "next/script";
import {
  Suspense,
  useCallback,
  useEffect,
  useMemo,
  useRef,
  useState,
} from "react";
import { z } from "zod";
import { Player } from "@remotion/player";
import { motion } from "framer-motion";
import {
  Sparkles,
  Image as ImageIcon,
  Film,
  Music2,
  Upload,
  Download,
  CheckCircle2,
  Share2,
  Copy as CopyIcon,
  Link2,
  Tag,
} from "lucide-react";

import DecorativeBG from "@/components/DecorativeBG";
import { FestivalIntro } from "@/remotion/FestivalIntro";
import { ImageCard } from "@/remotion/ImageCard";
import { templates } from "@/templates";
import { copy, getDefaults, type Lang } from "@/i18n/packs";
import {
  bgForTemplate,
  defaultMusicByTemplate,
  curatedTracks,
  curatedMap,
} from "@/lib/media-presets";
import { usePreloadImage, usePreloadAudio } from "@/lib/use-asset-preload";

type ExportPreset = "free" | "hd" | "status" | "gif";

/* --------------------------------------------- */
/* Query helper - no useSearchParams required    */
/* --------------------------------------------- */
function useQueryParam(name: string) {
  const [val, setVal] = useState<string>("");
  useEffect(() => {
    if (typeof window === "undefined") return;
    const usp = new URLSearchParams(window.location.search);
    setVal(usp.get(name) || "");
  }, [name]);
  return val;
}

/* --------------------------------------------- */
/* Festival → Template preselect map             */
/* --------------------------------------------- */
const FESTIVAL_TO_TEMPLATE: Record<string, string> = {
  diwali: "diwali",
  "chhath-puja": "chhath",
  "guru-nanak-jayanti": "guru-nanak",
  christmas: "christmas",
  "new-year": "new-year",
  lohri: "lohri",
  "makar-sankranti": "sankranti",
  pongal: "pongal",
  "republic-day": "republic-day",
};

/** Wish-only slugs: only title needed */
const WISH_SLUGS = new Set([
  "good-morning",
  "good-night",
  "congratulations",
  "best-of-luck",
  "get-well-soon",
  "thank-you",
]);

const baseSchema = z.object({
  template: z.string().min(1),
  language: z.enum(["en", "hi", "hinglish"]),
  title: z.string().min(1, "Title is required"),
  names: z.string().optional(),
  date: z.string().optional(),
  venue: z.string().optional(),
});

function schemaFor(slug: string) {
  if (WISH_SLUGS.has(slug)) return baseSchema;
  return baseSchema
    .extend({
      names: z.string().min(1, "Who is hosting?"),
      date: z.string().min(1, "Date required"),
    })
    .required();
}

type Mode = "video" | "image";
type TrackId = (typeof curatedTracks)[number]["id"];

/* --------------------------------------------- */
/* Small utils                                   */
/* --------------------------------------------- */
function readFileAsDataUrl(file: File): Promise<string> {
  return new Promise((resolve, reject) => {
    const fr = new FileReader();
    fr.onload = () => resolve(fr.result as string);
    fr.onerror = reject;
    fr.readAsDataURL(file);
  });
}

function downloadFromUrl(url: string, filename: string) {
  const a = document.createElement("a");
  a.href = url;
  a.download = filename;
  a.rel = "noopener";
  document.body.appendChild(a);
  a.click();
  a.remove();
  setTimeout(() => window.open(url, "_blank", "noopener"), 900);
}

async function copyToClipboard(txt: string) {
  try {
    await navigator.clipboard.writeText(txt);
    alert("Link copied!");
  } catch {
    // ignore
  }
}

function shareToWhatsApp(url: string, message = "Check this out!") {
  const shareText = `${message} ${url}`;
  const wa = `https://wa.me/?text=${encodeURIComponent(shareText)}`;
  window.open(wa, "_blank", "noopener");
}

function navigate(url: string) {
  if (typeof window !== "undefined") window.location.assign(url);
}

// --- Smart share helpers (add below navigate, above shortId) ---
const isMp4 = (name: string) => name.toLowerCase().endsWith(".mp4");
const isGif = (name: string) => name.toLowerCase().endsWith(".gif");
const mimeFromName = (name: string) =>
  isMp4(name) ? "video/mp4" : isGif(name) ? "image/gif" : "image/png";

async function shareSmartFileOrLink(opts: {
  url: string;
  filename: string;
  mimeHint: string; // e.g. "video/mp4" | "image/gif" | "image/png"
  preset?: ExportPreset | null; // "status" | "gif" | "free" | "hd"
}) {
  const { url, filename, mimeHint, preset } = opts;

  try {
    if (navigator.share) {
      // Try native FILE share first
      const resp = await fetch(url);
      const blob = await resp.blob();
      const type = blob.type || mimeHint;
      const file = new File([blob], filename, { type });

      if (navigator.canShare?.({ files: [file] })) {
        await navigator.share({
          files: [file],
          title: "Festival Invites",
          text:
            preset === "status"
              ? "Post this to your WhatsApp Status 🎉"
              : preset === "gif"
              ? "Share this festive GIF ✨"
              : "Made with Festival Invites",
        });
        return true;
      }

      // Fallback to link share via Web Share
      await navigator.share({
        url,
        title: "Festival Invites",
        text: "Made with Festival Invites",
      });
      return true;
    }
  } catch {
    // swallow and continue to fallbacks
  }

  // Link fallback → WhatsApp intent (opens app) → then copy
  try {
    const msg =
      preset === "status"
        ? "Here’s my invite—post it to your WhatsApp Status:"
        : "Check out my invite:";
    const wa = `https://wa.me/?text=${encodeURIComponent(`${msg} ${url}`)}`;
    window.open(wa, "_blank", "noopener");
    return true;
  } catch {}

  await copyToClipboard(url);
  alert("Link copied!");
  return false;
}
// --- end smart share helpers ---

// Client-side shortId so we can pre-assign inviteId before payment
function shortId(len = 8) {
  const bytes = new Uint8Array(len);
  if (typeof crypto !== "undefined" && "getRandomValues" in crypto) {
    crypto.getRandomValues(bytes);
  } else {
    for (let i = 0; i < len; i++) bytes[i] = Math.floor(Math.random() * 256);
  }
  const dict = "0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ";
  let out = "";
  for (const b of bytes) out += dict[b % dict.length];
  return out;
}

// Brand kit state
const [brandLogo, setBrandLogo] = useState<string>("");
const [brandName, setBrandName] = useState<string>("");
const [brandTagline, setBrandTagline] = useState<string>("");
const [brandPrimary, setBrandPrimary] = useState<string>("#2563eb");
const [brandSecondary, setBrandSecondary] = useState<string>("#a855f7");
const [brandRibbon, setBrandRibbon] = useState<boolean>(true);
const [brandEndCard, setBrandEndCard] = useState<boolean>(true);
const [brandId, setBrandId] = useState<string | null>(null);
const [myBrands, setMyBrands] = useState<Array<{
  id: string;
  name: string;
}> | null>(null);

useEffect(() => {
  // Load recent brands for quick apply
  fetch("/api/brands")
    .then((r) => r.json())
    .then((j) => {
      const items = (j.items || []).map((x: any) => ({
        id: x.id,
        name: x.name || "(untitled)",
      }));
      setMyBrands(items);
    })
    .catch(() => {});
}, []);

/* --------------------------------------------- */
/* Inner page                                    */
/* --------------------------------------------- */
function BuilderPageInner() {
  // Query params (no useSearchParams)
  const festivalSlugQP = useQueryParam("festival");
  const directTemplateQP = useQueryParam("template");

  // Map to template if ?festival= provided
  const mappedFromFestival = festivalSlugQP
    ? FESTIVAL_TO_TEMPLATE[festivalSlugQP]
    : "";
  const initialSlug = directTemplateQP || mappedFromFestival || "diwali";

  const [template, setTemplate] = useState(initialSlug);
  const [language, setLanguage] = useState<Lang>("en");

  const selectedFestival = useMemo(
    () => (festivalSlugQP ? festivalSlugQP : ""),
    [festivalSlugQP]
  );

  // Defaults
  const defaultsRef = useRef(getDefaults(initialSlug, "en"));
  const [names, setNames] = useState(defaultsRef.current.names);
  const [title, setTitle] = useState(defaultsRef.current.title);
  const [date, setDate] = useState(defaultsRef.current.date);
  const [venue, setVenue] = useState(defaultsRef.current.venue);

  // Owner info for public link
  const [ownerName, setOwnerName] = useState<string>("");
  const [ownerOrg, setOwnerOrg] = useState<string>("");

  const [errors, setErrors] = useState<Record<string, string>>({});
  const [mode, setMode] = useState<Mode>("video");

  // Payment & export state
  const [paid, setPaid] = useState(false);
  const [exportingWhich, setExportingWhich] = useState<null | "free" | "hd">(
    null
  );
  const [rzReady, setRzReady] = useState(false);
  const exporting = exportingWhich !== null;

  // Output
  const [downloadUrl, setDownloadUrl] = useState<string | null>(null);
  const [downloadName, setDownloadName] = useState<string>("invite.mp4");
  const hasOutput = !!downloadUrl;

  // Public page URL after we create it
  const [publicUrl, setPublicUrl] = useState<string | null>(null);
  const [lastPreset, setLastPreset] = useState<ExportPreset | null>(null);

  // Pre-assign a stable inviteId so payment entitlements attach to it
  const [inviteId] = useState<string>(() => shortId(8));

  // Template meta
  const meta = useMemo(
    () => templates.find((t) => t.slug === template) ?? templates[0],
    [template]
  );
  const isVideo = mode === "video";
  const isWish = WISH_SLUGS.has(template);

  // Background
  const [customBgDataUrl, setCustomBgDataUrl] = useState<string | null>(null);
  const defaultBgPath = bgForTemplate(template);
  const bgCandidate = customBgDataUrl ?? defaultBgPath;

  // Music
  const autoPreset = defaultMusicByTemplate[template] ?? {
    file: "",
    label: "",
    volume: 0.8,
  };
  const [trackId, setTrackId] = useState<TrackId>("auto");
  const [customMusic, setCustomMusic] = useState<string | null>(null);
  const [musicVolume, setMusicVolume] = useState<number>(autoPreset.volume);
  const musicFromCurated = curatedMap[trackId] || "";
  const musicCandidate =
    customMusic ??
    (trackId === "auto"
      ? autoPreset.file
      : trackId === "none"
      ? null
      : musicFromCurated);

  // Decode assets before sending to Player
  const { readyUrl: bgReadyUrl, status: bgStatus } =
    usePreloadImage(bgCandidate);
  const { readyUrl: musicReadyUrl, status: musicStatus } =
    usePreloadAudio(musicCandidate);
  const bgForPlayer: string | undefined = bgReadyUrl ?? undefined;
  const musicForPlayer: string | undefined = musicReadyUrl ?? undefined;

  // Force Player remount on key inputs
  const playerKey = `${mode}-${template}-${bgForPlayer ?? "noBg"}-${
    musicForPlayer ?? "noMusic"
  }-${paid ? "hd" : "free"}`;

  // Stronger watermark signals on free
  const wmSeed = useMemo(
    () => Math.floor(Math.random() * 1e9),
    [template, language]
  );
  const wmText = "Festival Invites - FREE PREVIEW";
  const wmStrategy: "ribbon" | "tile" | "ribbon+tile" = "ribbon+tile";
  const wmOpacity = 0.18;

  // Sync defaults when template or language changes
  const syncDefaults = (slug: string, lang: Lang) => {
    const next = getDefaults(slug, lang);
    const prev = defaultsRef.current;
    const same = (a: string, b: string) =>
      (a ?? "").trim() === (b ?? "").trim();
    if (same(title, prev.title)) setTitle(next.title);
    if (same(names ?? "", prev.names ?? "")) setNames(next.names ?? "");
    if (same(date ?? "", prev.date ?? "")) setDate(next.date ?? "");
    if (same(venue ?? "", prev.venue ?? "")) setVenue(next.venue ?? "");
    defaultsRef.current = next;
  };

  // Preselect on initial mount if festival implies a template
  useEffect(() => {
    if (mappedFromFestival && mappedFromFestival !== template) {
      setTemplate(mappedFromFestival);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  useEffect(() => {
    syncDefaults(template, language);
    setCustomBgDataUrl(null);
    if (!customMusic) {
      setTrackId("auto");
      const next = defaultMusicByTemplate[template];
      if (next) setMusicVolume(next.volume);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [template, language, customMusic]);

  // Client side validation
  useEffect(() => {
    const schema = schemaFor(template);
    const parsed = schema.safeParse({
      template,
      language,
      names,
      title,
      date,
      venue,
    });
    if (!parsed.success) {
      const e: Record<string, string> = {};
      for (const issue of parsed.error.issues)
        e[issue.path[0] as string] = issue.message;
      setErrors(e);
    } else setErrors({});
  }, [template, language, names, title, date, venue]);

  // Prefetch default background
  useEffect(() => {
    const bg = customBgDataUrl ?? bgForTemplate(template);
    if (!bg || bg.startsWith("data:")) return;
    const link = document.createElement("link");
    link.rel = "prefetch";
    link.as = "image";
    link.href = bg.startsWith("/") ? bg : `/${bg}`;
    document.head.appendChild(link);
    return () => {
      document.head.removeChild(link);
    };
  }, [template, customBgDataUrl]);

  const handleShare = useCallback(async () => {
    // Prefer sharing the public link (best for previews + wishboard)
    if (publicUrl) {
      await shareSmartFileOrLink({
        url: publicUrl,
        filename: "invite.html",
        mimeHint: "text/html",
        preset: lastPreset,
      });
      return;
    }

    // Otherwise share the exported file (MP4/GIF/PNG)
    if (!downloadUrl) return;
    await shareSmartFileOrLink({
      url: downloadUrl,
      filename: downloadName,
      mimeHint: mimeFromName(downloadName),
      preset: lastPreset,
    });
  }, [publicUrl, downloadUrl, downloadName, lastPreset]);

  function handleContinue() {
    document
      .getElementById("preview")
      ?.scrollIntoView({ behavior: "smooth", block: "start" });
  }

  /* --------------------------------------------- */
  /* Payment + export                              */
  /* --------------------------------------------- */
  async function handlePayAndExport() {
    try {
      if (!window.Razorpay)
        throw new Error("Payment is loading. Please try again in a moment.");

      // Choose plan based on mode
      const planId = isVideo ? "video_hd" : "image_hd";

      // Create order (Admin SDK-backed API)
      const orderRes = await fetch("/api/payments/create-order", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          planId,
          inviteId,
          customer: { name: ownerName || "Guest" },
        }),
      });
      const { order, error, detail } = await orderRes.json();
      if (!orderRes.ok || !order?.id) {
        throw new Error(error || detail || "Order creation failed");
      }

      const rzp = new window.Razorpay({
        key: process.env.NEXT_PUBLIC_RAZORPAY_KEY_ID,
        order_id: order.id,
        name: "Festival Invites",
        description: isVideo ? "HD Video Export" : "HD Image Export",
        theme: { color: "#2563EB" },
        prefill: { name: ownerName || "Guest" },
        handler: async (rsp: any) => {
          // Verify payment
          const vr = await fetch("/api/payments/verify", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({
              razorpay_order_id: rsp.razorpay_order_id,
              razorpay_payment_id: rsp.razorpay_payment_id,
              razorpay_signature: rsp.razorpay_signature,
            }),
          });
          const j = await vr.json();
          if (!vr.ok || !j?.ok) {
            alert(j?.error || "Payment verification failed");
            return;
          }
          setPaid(true);
          await doExportLambda("hd");
        },
      });

      rzp.on?.("payment.failed", (resp: any) => {
        alert(resp?.error?.description || "Payment failed");
      });

      rzp.open();
    } catch (e: any) {
      alert(e?.message || "Payment failed to start");
    }
  }

  async function doExportLambda(preset: ExportPreset) {
    try {
      // reflect spinner state for the primary buttons
      setLastPreset(preset);
      setExportingWhich(preset === "free" || preset === "hd" ? preset : "free");
      setDownloadUrl(null);
      setPublicUrl(null);

      // Choose composition:
      // - GIF always from video comp for motion
      // - otherwise respect current mode
      const isVideoComposition = preset === "gif" ? true : isVideo;
      const compositionId: "festival-intro" | "image-card" = isVideoComposition
        ? "festival-intro"
        : "image-card";

      // Choose endpoint based on preset
      const endpoint =
        preset === "gif"
          ? "/api/lambda/gif"
          : preset === "status"
          ? "/api/lambda/status"
          : isVideoComposition
          ? "/api/lambda/queue"
          : "/api/lambda/still";

      // Encoding hints (server can override if needed)
      const encoding =
        preset === "status"
          ? {
              width: 720,
              height: 1280,
              fps: 30,
              videoBitrateKbps: 2600,
              audioBitrateKbps: 96,
              maxDurationSeconds: 30,
            }
          : preset === "gif"
          ? {
              width: 540,
              height: 960,
              fps: 12,
              durationSeconds: 3.5,
            }
          : undefined;

      // Watermark/tier mapping
      const isHd = preset === "hd";
      const tier = isHd ? "hd" : "free";
      const showWatermark = !isHd; // watermark for free/status/gif

      const watermarkId = `wm_${Math.random().toString(36).slice(2, 8)}`;

      const inputProps: any = {
        title,
        names,
        date,
        venue,
        bg: bgForPlayer,
        music: musicForPlayer,
        musicVolume,
        tier,
        watermark: showWatermark,
        watermarkStrategy: showWatermark ? wmStrategy : "ribbon",
        wmSeed,
        wmText,
        wmOpacity,
        isWish,
        watermarkId,
        // BRAND PROPS
        brand: {
          id: brandId || undefined,
          name: brandName || undefined,
          logoUrl: brandLogo || undefined,
          tagline: brandTagline || undefined,
          primary: brandPrimary || undefined,
          secondary: brandSecondary || undefined,
          ribbon: brandRibbon,
          endCard: brandEndCard,
        },
      };

      const payload: any = {
        compositionId,
        quality: preset, // let your backend switch on this if needed
        inputProps,
        encoding,
      };

      // Still image options when using the image composition
      if (compositionId === "image-card" && preset !== "gif") {
        payload.frame = 60;
        payload.format = "png";
      }

      // Kick off render
      const queued = await fetch(endpoint, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      }).then((r) => r.json());

      if (!queued?.renderId || !queued?.bucketName) {
        throw new Error(queued?.error || "Queue error");
      }

      // Decide extension for final file
      const ext =
        preset === "gif"
          ? "gif"
          : isVideoComposition
          ? "mp4"
          : (payload.format as "png" | "jpeg");

      const guessedKey =
        queued?.outKey || `renders/${queued.renderId}/out.${ext}`;

      // Presign the output URL
      const signed = await fetch(
        `/api/lambda/file?bucketName=${
          queued.bucketName
        }&outKey=${encodeURIComponent(guessedKey)}&ext=${ext}`
      ).then((r) => r.json());
      if (!signed?.url) throw new Error("Failed to presign output URL");

      let finalUrl: string | null = null;
      const isLongRender =
        isVideoComposition || preset === "gif" || preset === "status";
      const deadline = Date.now() + (isLongRender ? 180_000 : 60_000);
      let delay = 900;

      if (isLongRender) {
        // Poll your progress endpoint
        while (Date.now() < deadline) {
          try {
            const res = await fetch(
              `/api/lambda/progress?renderId=${queued.renderId}&bucketName=${
                queued.bucketName
              }&functionName=${encodeURIComponent(queued.functionName)}`
            );
            if (res.status === 429) {
              await new Promise((r) => setTimeout(r, delay));
              delay = Math.min(delay * 1.6, 8000);
              continue;
            }
            const prog = await res.json();
            if (typeof prog?.error === "string") {
              if (prog.error.includes("Rate Exceeded")) {
                await new Promise((r) => setTimeout(r, delay));
                delay = Math.min(delay * 1.6, 8000);
                continue;
              }
              throw new Error(prog.error);
            }
            if (Array.isArray(prog?.errors) && prog.errors.length) {
              throw new Error(prog.errors[0]?.message || "Render failed");
            }
            if (prog?.done) {
              finalUrl = signed.url;
              break;
            }
          } catch {
            // tolerate transient network errors
          }
          await new Promise((r) => setTimeout(r, delay));
          delay = Math.min(delay * 1.25 + Math.random() * 200, 3000);
        }
      } else {
        // For stills, just probe the bucket
        while (Date.now() < deadline) {
          const probe = await fetch(
            `/api/lambda/probe?bucketName=${
              queued.bucketName
            }&outKey=${encodeURIComponent(guessedKey)}`
          ).then((r) => r.json());
          if (probe?.exists) {
            finalUrl = signed.url;
            break;
          }
          await new Promise((r) => setTimeout(r, delay));
          delay = Math.min(delay * 1.4, 5000);
        }
      }

      if (!finalUrl) throw new Error("Timed out waiting for render to finish");

      const filename =
        preset === "gif"
          ? "invite.gif"
          : isVideoComposition
          ? "invite.mp4"
          : "invite.png";

      setDownloadUrl(finalUrl);
      setDownloadName(filename);
      downloadFromUrl(finalUrl, filename);

      // --- Create (or upsert) public link immediately after export ---
      try {
        const selectedFestivalSlug = selectedFestival || template; // fall back to template slug
        const builderTitle = title;
        const builderSubtitle = names || "";
        const previewStillUrl =
          compositionId === "image-card" && preset !== "gif"
            ? finalUrl
            : undefined;

        const res = await fetch("/api/invites", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            // If you track an existing invite id, you can include it here:
            // id: inviteId,
            slug: selectedFestivalSlug,
            title: builderTitle,
            subtitle: builderSubtitle,
            mediaUrl: finalUrl,
            ogImageUrl: previewStillUrl, // omit for video/gif; add a real still later if you want
            theme: template,
            locale: language,
            owner: { name: ownerName || undefined, org: ownerOrg || null },
            props: {
              title,
              names,
              date,
              venue,
              bg: bgForPlayer,
              music: !!musicForPlayer,
              brand: {
                id: brandId || undefined,
                name: brandName || undefined,
                logoUrl: brandLogo || undefined,
                tagline: brandTagline || undefined,
                primary: brandPrimary || undefined,
                secondary: brandSecondary || undefined,
                ribbon: brandRibbon,
                endCard: brandEndCard,
              },
            },
            wishesEnabled: true,
          }),
        });
        const data = await res.json();
        if (data?.url) {
          setPublicUrl(data.url);
          // Optional: deep-link users straight to the public page for sharing
          navigate(data.url);
        }
      } catch {
        // non-blocking
      }
    } catch (e: any) {
      console.error("EXPORT ERROR", e);
      alert(e?.message || "Export error");
    } finally {
      setExportingWhich(null);
    }
  }

  const labels = copy[language].labels;
  const tierPreview: "free" | "hd" = paid ? "hd" : "free";

  return (
    <>
      <DecorativeBG />

      <Script
        src="https://checkout.razorpay.com/v1/checkout.js"
        strategy="afterInteractive"
        onLoad={() => setRzReady(true)}
      />

      {/* Toast when file is ready */}
      {downloadUrl && (
        <motion.div
          initial={{ y: 40, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          className="fixed inset-x-0 bottom-4 z-50 flex justify-center px-4"
          role="status"
          aria-live="polite"
        >
          <div className="max-w-3xl w-full rounded-2xl border border-white/50 bg-white/90 backdrop-blur-xl shadow-[0_20px_60px_rgba(0,0,0,0.15)] p-4 flex flex-wrap items-center justify-between gap-3">
            <div className="flex items-center gap-3">
              <div className="grid place-items-center h-10 w-10 rounded-xl bg-gradient-to-tr from-emerald-400 to-lime-400 text-white shadow">
                <CheckCircle2 className="h-5 w-5" />
              </div>
              <div className="text-sm">
                <div className="font-medium text-ink-900">
                  Your file is ready
                </div>
                <div className="text-ink-700">
                  If the download did not start, use the buttons.
                </div>
              </div>
            </div>
            <div className="flex flex-wrap items-center gap-2">
              <button
                type="button"
                onClick={() => downloadFromUrl(downloadUrl, downloadName)}
                className="inline-flex items-center justify-center gap-2 rounded-xl bg-indigo-600 px-4 py-2 text-white text-sm font-medium shadow hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-indigo-500"
              >
                <Download className="h-4 w-4" />
                Download
              </button>
              <button
                type="button"
                onClick={handleShare}
                className="inline-flex items-center justify-center gap-2 rounded-xl border border-gray-300 px-4 py-2 text-sm font-medium text-gray-900 hover:bg-gray-50"
                title="Share"
              >
                <Share2 className="h-4 w-4" />
                {publicUrl ? "Copy public link" : "Share"}
              </button>
              <button
                type="button"
                onClick={() =>
                  shareToWhatsApp(
                    publicUrl || downloadUrl!,
                    "Here is my invite:"
                  )
                }
                className="inline-flex items-center justify-center gap-2 rounded-xl border border-gray-300 px-4 py-2 text-sm font-medium text-gray-900 hover:bg-gray-50"
                title="WhatsApp"
              >
                <Link2 className="h-4 w-4" />
                WhatsApp
              </button>
              {!publicUrl ? null : (
                <button
                  type="button"
                  onClick={() => copyToClipboard(publicUrl)}
                  className="inline-flex items-center justify-center gap-2 rounded-xl border border-gray-300 px-3 py-2 text-sm font-medium text-gray-900 hover:bg-gray-50"
                  title="Copy public link"
                >
                  <CopyIcon className="h-4 w-4" />
                  Copy link
                </button>
              )}
            </div>
          </div>
        </motion.div>
      )}

      <main className="mx-auto max-w-6xl px-4 py-10">
        {/* Header */}
        <motion.header
          initial={{ opacity: 0, y: 12 }}
          animate={{ opacity: 1, y: 0 }}
          className="mb-6"
        >
          <div className="inline-flex items-center gap-2 rounded-full border border-white/40 bg-white/80 px-3 py-1 text-sm shadow-sm backdrop-blur">
            <Sparkles className="h-4 w-4 text-brand-600" />
            <span className="font-medium text-ink-700">
              Festive wishes & invite builder
            </span>
          </div>
          <h1 className="font-display mt-4 text-3xl sm:text-4xl leading-tight">
            Craft{" "}
            <span className="bg-gradient-to-tr from-amber-500 via-rose-500 to-violet-500 bg-clip-text text-transparent">
              mind-blowing invites
            </span>{" "}
            in seconds
          </h1>
          <p className="text-ink-700 mt-2">
            Pick a template, personalize details, add music — export & share on
            WhatsApp.
          </p>

          {selectedFestival && (
            <div className="mt-3 inline-flex items-center gap-2 rounded-full border border-amber-200 bg-amber-50 px-3 py-1 text-xs text-amber-800">
              <Tag className="h-3.5 w-3.5" />
              Selected festival:{" "}
              <strong className="ml-1">{selectedFestival}</strong>
            </div>
          )}
        </motion.header>

        <div className="grid gap-6 lg:grid-cols-[1.15fr_1fr]">
          {/* Left: Form */}
          <section className="rounded-2xl border border-white/60 bg-white/85 backdrop-blur-2xl shadow-[0_10px_40px_rgba(0,0,0,0.10)] p-6">
            <h2 className="font-display text-xl mb-4">
              1) Occasion and Language
            </h2>
            <div className="grid gap-4 sm:grid-cols-2">
              <div>
                <label className="block text-sm mb-1">Occasion</label>
                <div className="relative">
                  <select
                    value={template}
                    onChange={(e) => setTemplate(e.target.value)}
                    className="w-full rounded-xl border border-gray-300 bg-white px-3 py-2 pr-8"
                  >
                    {templates.map((t) => (
                      <option key={t.id} value={t.slug}>
                        {t.title}
                      </option>
                    ))}
                  </select>
                  <span
                    className={`pointer-events-none absolute inset-y-0 right-2 my-auto h-6 w-6 rounded-full bg-gradient-to-tr ${meta.accent} opacity-90 ring-1 ring-white/70`}
                    aria-hidden
                  />
                </div>
              </div>

              <div>
                <label className="block text-sm mb-1">Language</label>
                <select
                  value={language}
                  onChange={(e) => setLanguage(e.target.value as Lang)}
                  className="w-full rounded-xl border border-gray-300 bg-white px-3 py-2"
                >
                  <option value="en">English</option>
                  <option value="hi">हिंदी</option>
                  <option value="hinglish">Hinglish</option>
                </select>
              </div>
            </div>

            <h2 className="font-display text-xl mt-8 mb-4">2) Details</h2>
            <div className="grid gap-4 sm:grid-cols-2">
              <div className="sm:col-span-2">
                <label className="block text-sm mb-1">
                  {labels.eventTitle}
                </label>
                <input
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  className="w-full rounded-xl border border-gray-300 bg-white px-3 py-2"
                  placeholder={
                    copy[language].defaults[template]?.title ?? "Event Title"
                  }
                />
                {errors.title && (
                  <p className="mt-1 text-sm text-rose-600">{errors.title}</p>
                )}
              </div>

              {!isWish && (
                <>
                  <div>
                    <label className="block text-sm mb-1">{labels.hosts}</label>
                    <input
                      value={names}
                      onChange={(e) => setNames(e.target.value)}
                      className="w-full rounded-xl border border-gray-300 bg-white px-3 py-2"
                      placeholder={
                        copy[language].defaults[template]?.names ?? "Hosts"
                      }
                    />
                    {errors.names && (
                      <p className="mt-1 text-sm text-rose-600">
                        {errors.names}
                      </p>
                    )}
                  </div>

                  <div>
                    <label className="block text-sm mb-1">
                      {labels.dateTime}
                    </label>
                    <input
                      value={date}
                      onChange={(e) => setDate(e.target.value)}
                      className="w-full rounded-xl border border-gray-300 bg-white px-3 py-2"
                      placeholder={
                        copy[language].defaults[template]?.date ??
                        "Date and Time"
                      }
                    />
                    {errors.date && (
                      <p className="mt-1 text-sm text-rose-600">
                        {errors.date}
                      </p>
                    )}
                  </div>

                  <div className="sm:col-span-2">
                    <label className="block text-sm mb-1">{labels.venue}</label>
                    <input
                      value={venue}
                      onChange={(e) => setVenue(e.target.value)}
                      className="w-full rounded-xl border border-gray-300 bg-white px-3 py-2"
                      placeholder={
                        copy[language].defaults[template]?.venue ?? "Venue"
                      }
                    />
                  </div>
                </>
              )}

              {/* Owner info for public page */}
              <div>
                <label className="block text-sm mb-1">
                  Your name (for public link)
                </label>
                <input
                  value={ownerName}
                  onChange={(e) => setOwnerName(e.target.value)}
                  className="w-full rounded-xl border border-gray-300 bg-white px-3 py-2"
                  placeholder="e.g., Gautam"
                />
              </div>
              <div>
                <label className="block text-sm mb-1">
                  Brand/Org (optional)
                </label>
                <input
                  value={ownerOrg}
                  onChange={(e) => setOwnerOrg(e.target.value)}
                  className="w-full rounded-xl border border-gray-300 bg-white px-3 py-2"
                  placeholder="e.g., Botify"
                />
              </div>
            </div>

            {/* 3) Background */}
            <h2 className="font-display text-xl mt-8 mb-2">3) Background</h2>
            <div className="grid gap-3 sm:grid-cols-[1fr_auto] items-center">
              <div className="text-sm text-gray-700">
                Using{" "}
                <code className="rounded bg-gray-100 px-1.5 py-0.5">
                  {customBgDataUrl ? "Custom upload" : defaultBgPath}
                </code>
              </div>
              <div className="flex gap-2">
                <label className="inline-flex items-center justify-center gap-2 rounded-xl border border-gray-300 px-3 py-2 text-sm font-medium text-gray-900 hover:bg-gray-50 cursor-pointer">
                  <Upload className="h-4 w-4" />
                  <input
                    type="file"
                    accept="image/*"
                    className="sr-only"
                    onChange={async (e) => {
                      const f = e.target.files?.[0];
                      if (!f) return;
                      const data = await readFileAsDataUrl(f);
                      setCustomBgDataUrl(data);
                    }}
                  />
                  Upload image
                </label>
                <button
                  type="button"
                  className="inline-flex items-center justify-center rounded-xl border border-gray-300 px-3 py-2 text-sm font-medium text-gray-900 hover:bg-gray-50"
                  onClick={() => setCustomBgDataUrl(null)}
                  title="Use template default"
                >
                  Reset
                </button>
              </div>
            </div>

            {/* 4) Music */}
            <h2 className="font-display text-xl mt-8 mb-2">4) Music</h2>
            <div className="grid gap-3 sm:grid-cols-[1fr_auto] items-center">
              <div className="flex items-center gap-2">
                <Music2 className="h-4 w-4 text-ink-700" />
                <select
                  value={trackId}
                  onChange={(e) => setTrackId(e.target.value as TrackId)}
                  className="rounded-xl border border-gray-300 bg-white px-3 py-2"
                >
                  {curatedTracks.map((t) => (
                    <option key={t.id} value={t.id}>
                      {t.id === "auto" && defaultMusicByTemplate[template]
                        ? `Auto (recommended: ${defaultMusicByTemplate[template].label})`
                        : t.label}
                    </option>
                  ))}
                </select>
                <label className="inline-flex items-center gap-2 text-sm">
                  Volume
                  <input
                    type="range"
                    min={0}
                    max={1}
                    step={0.05}
                    value={musicVolume}
                    onChange={(e) => setMusicVolume(parseFloat(e.target.value))}
                  />
                </label>
              </div>

              <label className="inline-flex items-center justify-center gap-2 rounded-xl border border-gray-300 px-3 py-2 text-sm font-medium text-gray-900 hover:bg-gray-50 cursor-pointer">
                <Upload className="h-4 w-4" />
                <input
                  type="file"
                  accept="audio/*"
                  className="sr-only"
                  onChange={async (e) => {
                    const f = e.target.files?.[0];
                    if (!f) return;
                    const data = await readFileAsDataUrl(f);
                    setCustomMusic(data);
                    setTrackId("none");
                  }}
                />
                Upload music
              </label>
            </div>

            {/* 5) Brand Kit */}
            <h2 className="font-display text-xl mt-8 mb-2">5) Brand kit</h2>
            <div className="grid gap-4">
              <div className="grid sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-sm mb-1">
                    Brand/Company name
                  </label>
                  <input
                    value={brandName}
                    onChange={(e) => setBrandName(e.target.value)}
                    className="w-full rounded-xl border border-gray-300 bg-white px-3 py-2"
                    placeholder="e.g., Botify"
                  />
                </div>
                <div>
                  <label className="block text-sm mb-1">
                    Tagline (optional)
                  </label>
                  <input
                    value={brandTagline}
                    onChange={(e) => setBrandTagline(e.target.value)}
                    className="w-full rounded-xl border border-gray-300 bg-white px-3 py-2"
                    placeholder="e.g., Wishes from our team"
                  />
                </div>
              </div>

              <div className="grid sm:grid-cols-[1fr_auto_auto] items-center gap-3">
                <div>
                  <label className="block text-sm mb-1">Logo</label>
                  <input
                    value={brandLogo}
                    onChange={(e) => setBrandLogo(e.target.value)}
                    className="w-full rounded-xl border border-gray-300 bg-white px-3 py-2"
                    placeholder="https://... or leave blank and upload"
                  />
                </div>
                <label className="inline-flex items-center justify-center gap-2 rounded-xl border border-gray-300 px-3 py-2 text-sm font-medium text-gray-900 hover:bg-gray-50 cursor-pointer">
                  <Upload className="h-4 w-4" />
                  <input
                    type="file"
                    accept="image/*"
                    className="sr-only"
                    onChange={async (e) => {
                      const f = e.target.files?.[0];
                      if (!f) return;
                      const data = await readFileAsDataUrl(f);
                      setBrandLogo(data);
                    }}
                  />
                  Upload logo
                </label>
                <button
                  type="button"
                  className="rounded-xl border border-gray-300 px-3 py-2 text-sm"
                  onClick={() => setBrandLogo("")}
                >
                  Clear
                </button>
              </div>

              <div className="grid sm:grid-cols-2 gap-3">
                <div className="flex items-center gap-3">
                  <label className="text-sm">Primary</label>
                  <input
                    type="color"
                    value={brandPrimary}
                    onChange={(e) => setBrandPrimary(e.target.value)}
                  />
                  <input
                    className="flex-1 rounded-xl border border-gray-300 px-3 py-2 text-sm"
                    value={brandPrimary}
                    onChange={(e) => setBrandPrimary(e.target.value)}
                  />
                </div>
                <div className="flex items-center gap-3">
                  <label className="text-sm">Secondary</label>
                  <input
                    type="color"
                    value={brandSecondary}
                    onChange={(e) => setBrandSecondary(e.target.value)}
                  />
                  <input
                    className="flex-1 rounded-xl border border-gray-300 px-3 py-2 text-sm"
                    value={brandSecondary}
                    onChange={(e) => setBrandSecondary(e.target.value)}
                  />
                </div>
              </div>

              <div className="flex flex-wrap items-center gap-4">
                <label className="inline-flex items-center gap-2 text-sm">
                  <input
                    type="checkbox"
                    checked={brandRibbon}
                    onChange={(e) => setBrandRibbon(e.target.checked)}
                  />
                  Show corner ribbon/logo
                </label>
                <label className="inline-flex items-center gap-2 text-sm">
                  <input
                    type="checkbox"
                    checked={brandEndCard}
                    onChange={(e) => setBrandEndCard(e.target.checked)}
                  />
                  Add branded end-card
                </label>
                <button
                  type="button"
                  className="rounded-xl bg-emerald-600 text-white px-3 py-2 text-sm"
                  onClick={async () => {
                    const r = await fetch("/api/brands", {
                      method: "POST",
                      headers: { "Content-Type": "application/json" },
                      body: JSON.stringify({
                        id: brandId || undefined,
                        name: brandName,
                        logoUrl: brandLogo || undefined,
                        tagline: brandTagline || undefined,
                        primary: brandPrimary,
                        secondary: brandSecondary || undefined,
                        ribbon: brandRibbon,
                        endCard: brandEndCard,
                      }),
                    });
                    const j = await r.json();
                    if (r.ok && j.id) {
                      setBrandId(j.id);
                      alert("Brand saved");
                      // refresh quick list
                      fetch("/api/brands")
                        .then((r) => r.json())
                        .then((j) => {
                          const items = (j.items || []).map((x: any) => ({
                            id: x.id,
                            name: x.name || "(untitled)",
                          }));
                          setMyBrands(items);
                        })
                        .catch(() => {});
                    } else {
                      alert(j?.error || "Failed to save brand");
                    }
                  }}
                >
                  {brandId ? "Update brand" : "Save brand"}
                </button>

                {myBrands && myBrands.length > 0 && (
                  <div className="flex items-center gap-2">
                    <span className="text-sm text-gray-700">Apply saved:</span>
                    <select
                      className="rounded-xl border border-gray-300 bg-white px-3 py-2 text-sm"
                      onChange={async (e) => {
                        const id = e.target.value;
                        if (!id) return;
                        const r = await fetch(`/api/brands/${id}`);
                        const j = await r.json();
                        if (r.ok && j.item) {
                          const b = j.item;
                          setBrandId(b.id);
                          setBrandName(b.name || "");
                          setBrandTagline(b.tagline || "");
                          setBrandLogo(b.logoUrl || "");
                          setBrandPrimary(b.primary || "#2563eb");
                          setBrandSecondary(b.secondary || "#a855f7");
                          setBrandRibbon(!!b.ribbon);
                          setBrandEndCard(!!b.endCard);
                        }
                      }}
                    >
                      <option value="">Select</option>
                      {myBrands.map((b) => (
                        <option key={b.id} value={b.id}>
                          {b.name}
                        </option>
                      ))}
                    </select>
                  </div>
                )}
              </div>
            </div>

            {/* Actions */}
            <div className="mt-8 flex flex-wrap items-center gap-3">
              {/* Free */}
              <button
                type="button"
                className="inline-flex items-center justify-center gap-2 rounded-xl bg-white text-gray-900 border border-gray-300 px-4 py-2 text-sm font-medium shadow-sm hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-gray-400"
                onClick={() => doExportLambda("free")}
                disabled={exporting}
                aria-label="Download free with watermark"
                aria-busy={exportingWhich === "free"}
                title="SD with robust watermark"
              >
                {exportingWhich === "free" ? (
                  <>
                    <svg
                      className="animate-spin"
                      width="16"
                      height="16"
                      viewBox="0 0 24 24"
                      aria-hidden
                    >
                      <path
                        fill="currentColor"
                        d="M12 2v4a1 1 0 0 1-2 0V2a10 10 0 1 0 10 10h-4a1 1 0 0 1 0-2h4A10 10 0 0 0 12 2z"
                      />
                    </svg>
                    Rendering…
                  </>
                ) : (
                  <>
                    <Download className="h-4 w-4" />
                    {isVideo
                      ? "Download free (watermark)"
                      : "Download image (watermark)"}
                  </>
                )}
              </button>

              {/* HD */}
              <button
                type="button"
                className="inline-flex items-center justify-center gap-2 rounded-xl bg-gradient-to-tr from-indigo-600 to-violet-600 px-4 py-2 text-white text-sm font-medium shadow hover:opacity-95 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500"
                onClick={() =>
                  paid ? doExportLambda("hd") : handlePayAndExport()
                }
                disabled={exporting || !rzReady}
                aria-busy={exportingWhich === "hd"}
                title={
                  !rzReady
                    ? "Loading payment"
                    : "HD, no watermark, premium effects"
                }
                aria-label="Export HD without watermark"
              >
                {exportingWhich === "hd" ? (
                  <>
                    <svg
                      className="animate-spin"
                      width="16"
                      height="16"
                      viewBox="0 0 24 24"
                      aria-hidden
                    >
                      <path
                        fill="currentColor"
                        d="M12 2v4a1 1 0 0 1-2 0V2a10 10 0 1 0 10 10h-4a1 1 0 0 1 0-2h4A10 10 0 0 0 12 2z"
                      />
                    </svg>
                    Exporting…
                  </>
                ) : paid ? (
                  <>Export HD {isVideo ? "" : "(PNG)"} </>
                ) : (
                  <>Unlock HD</>
                )}
              </button>

              {/* Share */}
              <button
                type="button"
                onClick={handleShare}
                disabled={!hasOutput && !publicUrl}
                className="inline-flex items-center justify-center gap-2 rounded-xl border border-gray-300 px-4 py-2 text-sm font-medium text-gray-900 hover:bg-gray-50 disabled:opacity-60"
                title={
                  publicUrl
                    ? "Copy public link"
                    : hasOutput
                    ? "Share your file"
                    : "Export first to share"
                }
              >
                <Share2 className="h-4 w-4" />
                {publicUrl ? "Copy public link" : "Share"}
              </button>

              <button
                type="button"
                onClick={() =>
                  publicUrl
                    ? shareToWhatsApp(publicUrl, "Here is my invite:")
                    : hasOutput
                    ? shareToWhatsApp(downloadUrl!, "Here is my invite:")
                    : null
                }
                disabled={!hasOutput && !publicUrl}
                className="inline-flex items-center justify-center gap-2 rounded-xl border border-gray-300 px-4 py-2 text-sm font-medium text-gray-900 hover:bg-gray-50 disabled:opacity-60"
                title={
                  publicUrl
                    ? "Share link on WhatsApp"
                    : hasOutput
                    ? "Share file on WhatsApp"
                    : "Export first"
                }
              >
                <Link2 className="h-4 w-4" />
                WhatsApp
              </button>

              {/* WhatsApp Status preset */}
              <button
                type="button"
                className="inline-flex items-center justify-center gap-2 rounded-xl bg-white text-gray-900 border border-gray-300 px-4 py-2 text-sm font-medium shadow-sm hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-gray-400"
                onClick={() => {
                  setMode("video"); // ensure video composition
                  doExportLambda("status");
                }}
                disabled={exporting}
                title="Export for WhatsApp Status (9:16, ~30s, compact)"
              >
                <Download className="h-4 w-4" />
                Export Status
              </button>

              {/* Quick GIF preset */}
              <button
                type="button"
                className="inline-flex items-center justify-center gap-2 rounded-xl bg-white text-gray-900 border border-gray-300 px-4 py-2 text-sm font-medium shadow-sm hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-gray-400"
                onClick={() => {
                  setMode("video"); // GIF from motion for best effect
                  doExportLambda("gif");
                }}
                disabled={exporting}
                title="Export short looping GIF (lightweight)"
              >
                <ImageIcon className="h-4 w-4" />
                Export GIF
              </button>

              <div className="text-sm text-gray-700 space-y-1">
                <div>Free: SD with robust watermark</div>
                <div>HD: No watermark, sharper, premium effects</div>
              </div>
            </div>

            <div className="mt-6">
              <button
                type="button"
                onClick={handleContinue}
                className="inline-flex items-center justify-center rounded-xl border border-gray-300 px-4 py-2 text-sm font-medium text-gray-900 hover:bg-gray-50"
              >
                Continue
              </button>
            </div>
          </section>

          {/* Right: Preview */}
          <section
            id="preview"
            className="rounded-2xl border border-white/60 bg-white/85 backdrop-blur-2xl shadow-[0_10px_40px_rgba(0,0,0,0.10)] p-4"
          >
            <div className="mb-3 flex items-center justify-between">
              <h2 className="font-display text-xl">
                {isWish ? "Wish Preview" : "Live Preview"}
              </h2>

              <div className="inline-flex rounded-2xl border border-gray-200 bg-white p-1">
                <button
                  type="button"
                  onClick={() => setMode("video")}
                  className={`px-3 py-1.5 text-sm rounded-lg flex items-center gap-1.5 ${
                    mode === "video"
                      ? "bg-indigo-600 text-white"
                      : "text-gray-800"
                  }`}
                >
                  <Film className="h-4 w-4" />
                  Video 9:16
                </button>
                <button
                  type="button"
                  onClick={() => setMode("image")}
                  className={`px-3 py-1.5 text-sm rounded-lg flex items-center gap-1.5 ${
                    mode === "image"
                      ? "bg-indigo-600 text-white"
                      : "text-gray-800"
                  }`}
                >
                  <ImageIcon className="h-4 w-4" />
                  Image 1:1
                </button>
              </div>
            </div>

            <div className="rounded-xl overflow-hidden border bg-white relative shadow-sm">
              <div
                className={`pointer-events-none absolute inset-0 opacity-30 bg-gradient-to-tr ${meta.accent}`}
                aria-hidden
              />
              <div className="relative">
                {mode === "video" ? (
                  <Player
                    key={playerKey}
                    component={FestivalIntro}
                    autoPlay
                    loop
                    durationInFrames={paid ? 180 : 150}
                    fps={30}
                    compositionWidth={720}
                    compositionHeight={1280}
                    inputProps={{
                      title,
                      names,
                      date,
                      venue,
                      bg: bgForPlayer,
                      music: musicForPlayer,
                      musicVolume,
                      tier: paid ? "hd" : "free",
                      watermark: !paid,
                      watermarkStrategy: !paid ? wmStrategy : "ribbon",
                      wmSeed,
                      wmText,
                      wmOpacity,
                      isWish,
                    }}
                    acknowledgeRemotionLicense
                    style={{
                      width: "100%",
                      height: 520,
                      background: "transparent",
                    }}
                  />
                ) : (
                  <Player
                    key={playerKey}
                    component={ImageCard}
                    autoPlay
                    loop
                    durationInFrames={120}
                    fps={30}
                    compositionWidth={1080}
                    compositionHeight={1080}
                    inputProps={{
                      title,
                      names,
                      date,
                      venue,
                      bg: bgForPlayer,
                      tier: paid ? "hd" : "free",
                      watermark: !paid,
                      watermarkStrategy: !paid ? wmStrategy : "ribbon",
                      wmSeed,
                      wmText,
                      wmOpacity,
                      isWish,
                    }}
                    acknowledgeRemotionLicense
                    style={{
                      width: "100%",
                      height: 520,
                      background: "transparent",
                    }}
                  />
                )}
              </div>
            </div>

            <p className="mt-3 text-sm text-gray-700">
              Free preview shows an anti-crop watermark. HD removes it and adds
              premium effects.
            </p>

            {(bgStatus === "loading" || musicStatus === "loading") && (
              <span className="absolute right-3 top-3 rounded-full bg-black/60 text-white px-2 py-0.5 text-xs">
                Updating preview…
              </span>
            )}
          </section>
        </div>
      </main>
    </>
  );
}

/* --------------------------------------------- */
/* Page wrapper for Suspense                     */
/* --------------------------------------------- */
export default function BuilderPage() {
  return (
    <Suspense fallback={null}>
      <BuilderPageInner />
    </Suspense>
  );
}
