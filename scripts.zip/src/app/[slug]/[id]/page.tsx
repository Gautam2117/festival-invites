// src/app/[slug]/[id]/page.tsx
import Image from "next/image";
import ShareBar from "@/components/ShareBar";
import type { Metadata } from "next";
import type { Invite } from "@/types/invite";
import dynamic from "next/dynamic";
import InviteAnalytics from "@/components/InviteAnalytics";

const WishForm = dynamic(() => import("@/components/WishForm"), { ssr: false });
const WishList = dynamic(() => import("@/components/WishList"), { ssr: false });
const WishMontageButton = dynamic(
  () => import("@/components/WishMontageButton"),
  { ssr: false }
);

/** Fetch via API so the page + metadata share one code path */
async function fetchInvite(id: string): Promise<Invite | null> {
  const base = process.env.NEXT_PUBLIC_BASE_URL;
  // Fail fast if base URL is missing (avoids silent 404s during early setup)
  if (!base) return null;

  const r = await fetch(`${base}/api/invites/${id}`, {
    // Edge-friendly; refresh often during launch
    next: { revalidate: 60 },
  });
  if (!r.ok) return null;
  const data = await r.json();
  return data.item as Invite;
}

type Params = { params: { slug: string; id: string } };

/** SEO / Social cards (robust OG cover) */
export async function generateMetadata({ params }: Params): Promise<Metadata> {
  const inv = await fetchInvite(params.id);
  if (!inv) return { title: "Invite not found" };

  const title = inv.title || "Invitation";
  const desc = inv.subtitle || "Join the celebration";
  const base = process.env.NEXT_PUBLIC_BASE_URL || "";
  const canonical = `/${inv.slug}/${inv.id}`;
  const url = `${base}${canonical}`;

  const looksLikeImage = (u?: string) =>
    !!u && /\.(png|jpg|jpeg|webp|gif)$/i.test(u || "");

  // Prefer a real image for OG (png/jpg/webp/gif)
  let ogUrl: string | undefined =
    inv.ogImageUrl && looksLikeImage(inv.ogImageUrl)
      ? inv.ogImageUrl
      : undefined;

  // If none, try to ensure a PNG cover via API
  if (!ogUrl && base) {
    try {
      const ensure = await fetch(`${base}/api/invites/${inv.id}/og`, {
        cache: "no-store",
      });
      const j = await ensure.json();
      if (ensure.ok && j?.url) ogUrl = j.url as string;
    } catch {
      // swallow; we’ll fall back below
    }
  }

  // Last resort: use mediaUrl (OK if image; platforms may ignore video)
  const finalOg = ogUrl || inv.mediaUrl;

  return {
    title,
    description: desc,
    openGraph: {
      title,
      description: desc,
      type: "website",
      url,
      images: finalOg ? [{ url: finalOg }] : [],
    },
    twitter: {
      card: "summary_large_image",
      title,
      description: desc,
      images: finalOg ? [finalOg] : [],
    },
    alternates: { canonical },
    metadataBase: base ? new URL(base) : undefined,
  };
}

export default async function InvitePage({ params }: Params) {
  const inv = await fetchInvite(params.id);

  if (!inv || inv.slug !== params.slug) {
    return (
      <main className="mx-auto max-w-2xl px-4 py-12">
        <h1 className="text-xl font-semibold">Invite not found</h1>
        <p className="mt-2 text-sm text-zinc-600">
          The link may be incorrect or has been removed.
        </p>
      </main>
    );
  }

  const url = `${process.env.NEXT_PUBLIC_BASE_URL}/${inv.slug}/${inv.id}`;
  const isVideo = /\.(mp4|webm|mov)$/i.test(inv.mediaUrl);

  return (
    <>
      <main className="mx-auto max-w-3xl px-4 py-10">
        {/* Soft festive header */}
        <div className="mb-6">
          <div className="inline-flex items-center gap-2 rounded-full border border-white/50 bg-white/80 px-3 py-1 text-xs text-ink-700 shadow-sm backdrop-blur">
            Invitation
          </div>
          <h1 className="mt-3 text-2xl font-semibold">
            <span className="bg-gradient-to-tr from-amber-500 via-rose-500 to-violet-500 bg-clip-text text-transparent">
              {inv.title}
            </span>
          </h1>
          {inv.subtitle && <p className="mt-1 text-ink-700">{inv.subtitle}</p>}
        </div>

        {/* Media frame (light/glassy) */}
        <div className="overflow-hidden rounded-2xl border border-white/70 bg-white/80 backdrop-blur shadow-sm">
          {isVideo ? (
            <video
              src={inv.mediaUrl}
              controls
              playsInline
              preload="metadata"
              className="h-auto w-full bg-black"
              poster={inv.ogImageUrl || undefined}
            />
          ) : (
            <div className="relative w-full">
              {/* fixed ratio container for pleasant layout */}
              <div className="relative mx-auto aspect-[9/16] w-full max-w-[540px]">
                <Image
                  src={inv.mediaUrl}
                  alt={inv.title}
                  fill
                  sizes="100vw"
                  className="object-cover"
                  priority
                />
              </div>
            </div>
          )}
        </div>

        {/* Share + Wishes */}
        <div className="mt-6 flex items-center justify-between gap-4">
          <ShareBar title={inv.title} url={url} />
          <div className="flex items-center gap-2">
            {inv.wishesEnabled && <WishMontageButton inviteId={inv.id} />}
            {inv.wishesEnabled && (
              <a
                href={`/${inv.slug}/${inv.id}#wishes`}
                className="rounded-lg bg-gradient-to-tr from-emerald-600 to-teal-600 px-4 py-2 text-sm font-medium text-white shadow hover:opacity-95"
              >
                Send a wish
              </a>
            )}
          </div>
        </div>

        {inv.wishesEnabled && (
          <section id="wishes" className="mt-10">
            <h2 className="text-lg font-semibold">Wishes</h2>
            <div className="mt-4 grid gap-6 md:grid-cols-2">
              <WishForm inviteId={inv.id} />
              <div>
                <WishList inviteId={inv.id} />
              </div>
            </div>
          </section>
        )}
      </main>

      {/* 🔔 fire analytics once on client mount */}
      <InviteAnalytics inviteId={inv.id} />
    </>
  );
}
