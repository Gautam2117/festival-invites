// src/remotion/WishMontage.tsx
"use client";

import React from "react";
import {
  AbsoluteFill,
  Audio,
  Img,
  Easing,
  interpolate,
  random,
  staticFile,
  useCurrentFrame,
  useVideoConfig,
} from "remotion";

type WishLite = {
  message: string;
  senderName?: string;
  senderType?: "company" | "family" | "personal";
  logoUrl?: string | null;
  createdAt?: number;
};

type BrandInput = {
  name?: string;
  logoUrl?: string;
  tagline?: string;
  primary?: string;
  secondary?: string;
  ribbon?: boolean;  // not used here, but kept for parity
  endCard?: boolean; // not used here (montage is short)
};

type Props = {
  wishes: WishLite[];     // already filtered/trimmed by the API
  bg?: string;            // background image path or data: URL
  music?: string | null;  // optional gentle bed
  musicVolume?: number;   // 0..1
  brand?: BrandInput;     // optional accent colors/logo
  theme?: string;         // optional theme token (for future)
};

const resolve = (src?: string | null) => {
  if (!src) return null;
  if (src.startsWith("data:")) return src;
  const p = src.startsWith("/") ? src : `/${src}`;
  return staticFile(p);
};

const clamp01 = (n: number) => Math.max(0, Math.min(1, n));

const Bokeh: React.FC<{ count: number; seed: string }> = ({ count, seed }) => {
  const frame = useCurrentFrame();
  const { height, width, fps } = useVideoConfig();

  return (
    <>
      {new Array(count).fill(0).map((_, i) => {
        const r = (t: number) => random(`${seed}-${i}-${t}`);
        const size = 40 + r(0) * 70;
        const startX = r(1) * (width + 200) - 100;
        const baseY = r(2) * height;
        const speed = 12 + r(3) * 22; // px/sec
        const drift = Math.sin((frame / fps) * 1.2 + r(4) * 6.28) * 60;

        // float upwards slowly
        const y = (baseY - (frame / fps) * speed) % (height + 120);
        const x = startX + drift;

        const o = 0.12 + r(5) * 0.15;
        return (
          <div
            key={i}
            style={{
              position: "absolute",
              left: x,
              top: y,
              width: size,
              height: size,
              borderRadius: size,
              background:
                "radial-gradient(circle at 30% 30%, rgba(255,255,255,0.35), rgba(255,255,255,0) 60%)",
              filter: "blur(0.5px)",
              opacity: o,
              mixBlendMode: "screen",
            }}
          />
        );
      })}
    </>
  );
};

const WishCard: React.FC<{
  w: WishLite;
  slotStart: number; // frame
  slotEnd: number;   // frame
  primary: string;
  secondary?: string;
}> = ({ w, slotStart, slotEnd, primary, secondary }) => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();

  // in/out timing inside the slot
  const fadeIn = interpolate(frame, [slotStart, slotStart + Math.round(fps * 0.35)], [0, 1], {
    easing: Easing.out(Easing.cubic),
    extrapolateLeft: "clamp",
    extrapolateRight: "clamp",
  });
  const fadeOut = interpolate(frame, [slotEnd - Math.round(fps * 0.4), slotEnd], [1, 0], {
    easing: Easing.in(Easing.cubic),
    extrapolateLeft: "clamp",
    extrapolateRight: "clamp",
  });
  const appear = clamp01(fadeIn * fadeOut);

  // gentle vertical drift for the card
  const y = interpolate(
    frame,
    [slotStart, slotEnd],
    [8, -8],
    { extrapolateLeft: "clamp", extrapolateRight: "clamp" }
  );

  return (
    <div
      style={{
        position: "absolute",
        left: "50%",
        top: "50%",
        transform: `translate(-50%, calc(-50% + ${y}px))`,
        width: Math.min(560, 0.76 * 720),
        opacity: appear,
      }}
    >
      <div
        style={{
          borderRadius: 20,
          padding: "16px 18px",
          background: "rgba(0,0,0,0.35)",
          border: "1px solid rgba(255,255,255,0.22)",
          color: "white",
          boxShadow: "0 14px 44px rgba(0,0,0,0.35)",
          backdropFilter: "blur(8px) saturate(1.15)",
          WebkitBackdropFilter: "blur(8px) saturate(1.15)",
        }}
      >
        {/* sender header */}
        <div style={{ display: "flex", alignItems: "center", gap: 10, marginBottom: 8 }}>
          {w.logoUrl ? (
            // eslint-disable-next-line @next/next/no-img-element
            <img
              src={w.logoUrl}
              width={26}
              height={26}
              alt="logo"
              style={{ borderRadius: 6, objectFit: "cover" }}
            />
          ) : null}
          <div style={{ fontWeight: 700, fontSize: 14, letterSpacing: 0.2, opacity: 0.95 }}>
            {w.senderName ?? "Anonymous"}
            {w.senderType ? ` · ${w.senderType}` : ""}
          </div>
        </div>

        {/* message */}
        <div style={{ fontSize: 20, lineHeight: 1.35, fontWeight: 600, letterSpacing: 0.2 }}>
          {w.message}
        </div>

        {/* small accent rule */}
        <div
          style={{
            marginTop: 10,
            width: 46,
            height: 3,
            borderRadius: 3,
            background: secondary || primary,
            opacity: 0.95,
          }}
        />
      </div>
    </div>
  );
};

export const WishMontage: React.FC<Props> = ({
  wishes,
  bg,
  music,
  musicVolume = 0.8,
  brand,
}) => {
  const frame = useCurrentFrame();
  const { width, height, fps, durationInFrames } = useVideoConfig();

  const bgSrc = resolve(bg);
  const musicSrc = resolve(music);

  // Gentle rotating glow underlay
  const angle = interpolate(frame, [0, durationInFrames], [0, 360], {
    easing: Easing.linear,
  });

  // compute slots
  const safe = Math.max(1, Math.min(8, wishes.length || 1));
  // intro/outro budget
  const intro = Math.round(fps * 0.5);
  const outro = Math.round(fps * 0.5);
  const body = Math.max(1, durationInFrames - intro - outro);
  const per = Math.max(Math.round(body / safe), Math.round(fps * 1.4)); // ≥1.4s per wish

  const primary = brand?.primary || "#10b981";
  const secondary = brand?.secondary || "#a78bfa";

  return (
    <AbsoluteFill style={{ backgroundColor: "#060606", overflow: "hidden" }}>
      {/* animated glow */}
      <div
        style={{
          position: "absolute",
          inset: "-20%",
          background: `conic-gradient(from ${angle}deg, #FFB74D, #FF7043, #F06292, #7C4DFF, #FFB74D)`,
          filter: "blur(60px) saturate(1.1)",
          opacity: 0.55,
        }}
      />

      {/* background image */}
      {bgSrc && (
        <Img
          src={bgSrc}
          style={{
            position: "absolute",
            inset: 0,
            width: "100%",
            height: "100%",
            objectFit: "cover",
            transform: `scale(1.08)`,
            filter: "saturate(1.03) contrast(1.02)",
          }}
        />
      )}

      <Bokeh count={28} seed="wb-bokeh" />

      {/* Legibility veil */}
      <div
        style={{
          position: "absolute",
          inset: 0,
          background:
            "linear-gradient(to bottom, rgba(255,255,255,0.08), rgba(0,0,0,0.28) 70%, rgba(0,0,0,0.55))",
        }}
      />

      {/* Title chip at the top (subtle) */}
      <div
        style={{
          position: "absolute",
          top: 24,
          left: "50%",
          transform: "translateX(-50%)",
          background: "rgba(0,0,0,0.35)",
          border: "1px solid rgba(255,255,255,0.22)",
          color: "#fff",
          borderRadius: 999,
          padding: "6px 12px",
          fontSize: 14,
          fontWeight: 700,
          letterSpacing: 0.3,
        }}
      >
        Wishboard Highlights
      </div>

      {/* Wishes timeline */}
      {wishes.slice(0, safe).map((w, i) => {
        const slotStart = intro + i * per;
        const slotEnd = Math.min(durationInFrames - outro, slotStart + per);
        return (
          <WishCard
            key={i}
            w={w}
            slotStart={slotStart}
            slotEnd={slotEnd}
            primary={primary}
            secondary={secondary}
          />
        );
      })}

      {/* Optional bottom chip with brand */}
      {(brand?.logoUrl || brand?.name) && (
        <div
          style={{
            position: "absolute",
            bottom: 18,
            left: "50%",
            transform: "translateX(-50%)",
            display: "inline-flex",
            alignItems: "center",
            gap: 10,
            background: "rgba(0,0,0,0.35)",
            color: "white",
            padding: "8px 12px",
            borderRadius: 999,
            border: "1px solid rgba(255,255,255,0.22)",
          }}
        >
          {brand.logoUrl ? (
            // eslint-disable-next-line @next/next/no-img-element
            <img
              src={brand.logoUrl}
              alt="logo"
              width={20}
              height={20}
              style={{ borderRadius: 6, objectFit: "cover" }}
            />
          ) : null}
          <span style={{ fontSize: 12, fontWeight: 700 }}>{brand?.name}</span>
        </div>
      )}

      {musicSrc && (
        <Audio
          src={musicSrc}
          volume={(f) => {
            const fadeIn = interpolate(f, [0, 20], [0, 1], { extrapolateRight: "clamp" });
            const fadeOut = interpolate(
              f,
              [durationInFrames - 24, durationInFrames],
              [1, 0],
              { extrapolateLeft: "clamp" }
            );
            return clamp01((musicVolume ?? 0.8) * fadeIn * fadeOut);
          }}
        />
      )}
    </AbsoluteFill>
  );
};
