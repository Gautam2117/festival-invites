import React from "react";
import { AbsoluteFill, interpolate, useCurrentFrame, useVideoConfig } from "remotion";

type Props = {
  title: string;
  subtitle?: string;
  date?: string;
  venue?: string;
  bg?: string | null;        // background image URL (optional)
  theme?: "classic" | "gold" | string;
  ownerName?: string;
  ownerOrg?: string | null;
};

// Simple, clean OG card (landscape 1200×630)
export const OGCard: React.FC<Props> = ({
  title,
  subtitle,
  date,
  venue,
  bg,
  theme = "classic",
  ownerName,
  ownerOrg,
}) => {
  const frame = useCurrentFrame();
  const { width, height, fps } = useVideoConfig();
  const fade = interpolate(frame, [0, fps / 2], [0, 1], { extrapolateRight: "clamp" });

  const accent =
    theme === "gold"
      ? "linear-gradient(135deg,#f59e0b,#f43f5e)"
      : "linear-gradient(135deg,#6366f1,#a855f7)";

  return (
    <AbsoluteFill
      style={{
        background: bg ? `#111 url(${bg}) center/cover no-repeat` : "#0b1020",
        fontFamily:
          '-apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Inter, "Helvetica Neue", Arial, "Noto Sans", "Apple Color Emoji", "Segoe UI Emoji"',
        color: "#0f172a",
      }}
    >
      {/* glass layer */}
      <AbsoluteFill
        style={{
          background: "linear-gradient(180deg, rgba(255,255,255,.86), rgba(255,255,255,.86))",
          backdropFilter: "blur(4px)",
        }}
      />
      {/* accent ribbon */}
      <div
        style={{
          position: "absolute",
          inset: 0,
          background: accent,
          opacity: 0.18,
          maskImage:
            "radial-gradient(90% 90% at 100% 0%, black 20%, transparent 60%)",
        }}
      />
      {/* content */}
      <div
        style={{
          position: "absolute",
          inset: 0,
          padding: 48,
          display: "grid",
          gridTemplateRows: "1fr auto",
        }}
      >
        <div style={{ alignSelf: "center" }}>
          {subtitle ? (
            <div style={{ fontSize: 28, color: "#334155", marginBottom: 10, opacity: 0.9 }}>
              {subtitle}
            </div>
          ) : null}
          <div
            style={{
              fontWeight: 800,
              fontSize: 64,
              lineHeight: 1.05,
              color: "#0f172a",
              textShadow: "0 1px 0 #fff",
              opacity: fade,
            }}
          >
            {title}
          </div>

          {(date || venue) && (
            <div style={{ marginTop: 16, display: "flex", gap: 24, color: "#334155" }}>
              {date && <div style={{ fontSize: 24 }}>📅 {date}</div>}
              {venue && <div style={{ fontSize: 24 }}>📍 {venue}</div>}
            </div>
          )}
        </div>

        {(ownerName || ownerOrg) && (
          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
            <div style={{ fontSize: 18, color: "#475569" }}>
              Made by <strong>{ownerName || "Guest"}</strong>
              {ownerOrg ? ` · ${ownerOrg}` : ""}
            </div>
            <div
              style={{
                padding: "8px 14px",
                borderRadius: 999,
                background: "#111827",
                color: "white",
                fontSize: 16,
                fontWeight: 600,
              }}
            >
              festivalinvites.app
            </div>
          </div>
        )}
      </div>

      {/* subtle border */}
      <div
        style={{
          position: "absolute",
          inset: 0,
          borderRadius: 20,
          border: "1px solid rgba(255,255,255,.7)",
          boxShadow: "0 30px 80px rgba(0,0,0,.18) inset",
          pointerEvents: "none",
        }}
      />
    </AbsoluteFill>
  );
};
