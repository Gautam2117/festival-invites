import React from "react";
import { Composition } from "remotion";
import { FestivalIntro } from "./FestivalIntro";
import { ImageCard } from "./ImageCard";
import { OGCard } from "./OGCard";
import { WishMontage } from "./WishMontage"; // ← NEW

export const RemotionRoot: React.FC = () => {
  return (
    <>
      {/* Vertical video (9:16) */}
      <Composition
        id="festival-intro"
        component={FestivalIntro}
        fps={30}
        width={720}
        height={1280}
        durationInFrames={180}
        defaultProps={{
          title: "Diwali Celebration",
          names: "The Sharma Family",
          date: "Sun, Nov 2 · 7 PM",
          venue: "Sharma Residence, Pune",
          bg: "/assets/bg/diwali.jpg",
          music: "/assets/music/festive-brass.mp3",
          musicVolume: 0.8,
          tier: "free",
          watermark: true,
        }}
      />

      {/* NEW: Wishboard montage (vertical status) */}
      <Composition
        id="wish-montage"
        component={WishMontage}
        fps={30}
        width={720}
        height={1280}
        durationInFrames={330} // ~11s; adjust 300–450 for 10–15s
        defaultProps={{
          wishes: [{ message: "Have a wonderful celebration!", senderName: "A friend" }],
          bg: "/assets/bg/diwali.jpg",
          music: "/assets/music/soft-bed.mp3",
          musicVolume: 0.9,
          brand: { name: "Your Brand", primary: "#10b981", secondary: "#a78bfa" },
        }}
      />

      {/* Square image (1:1) — still */}
      <Composition
        id="image-card"
        component={ImageCard}
        fps={30}
        width={1080}
        height={1080}
        durationInFrames={120}
        defaultProps={{
          title: "Happy Diwali",
          names: "From the Sharma Family",
          date: "Nov 2, 2025",
          venue: "Pune",
          bg: "/assets/bg/diwali.jpg",
          tier: "free",
          watermark: true,
        }}
      />

      {/* Landscape OG (1200×630) */}
      <Composition
        id="og-card"
        component={OGCard}
        fps={30}
        width={1200}
        height={630}
        durationInFrames={90}
        defaultProps={{
          title: "Invitation",
          subtitle: "Join the celebration",
          date: "Sun, Nov 2 · 7 PM",
          venue: "Sharma Residence, Pune",
          bg: "/assets/bg/diwali.jpg",
          theme: "classic",
          ownerName: "Gautam",
          ownerOrg: "Botify",
        }}
      />
    </>
  );
};
