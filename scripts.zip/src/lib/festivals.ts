import list from "@/data/festivals-2025.json";
import type { Festival } from "@/types/festival";

const IST = "Asia/Kolkata";

function nowIST(): Date {
  // Build "now" in IST by formatting and re-parsing to strip time drift
  const d = new Date();
  const parts = new Intl.DateTimeFormat("en-GB", {
    timeZone: IST, year: "numeric", month: "2-digit", day: "2-digit"
  }).formatToParts(d);
  const get = (t: string) => Number(parts.find(p => p.type === t)?.value);
  // month is 1-based in output, 0-based in Date
  return new Date(get("year"), get("month") - 1, get("day"));
}

function toDateISO(x: string): Date {
  // Treat as local midnight IST to avoid off-by-one on comparisons
  // We interpret x as UTC midnight and compare date-only values.
  return new Date(x + "T00:00:00.000Z");
}

export type UpcomingParams = {
  days?: number;
  region?: string;   // "IN" or "IN-TN" etc
  tags?: string[];   // must include all provided tags if set
};

export function getAll(): Festival[] {
  return (list as Festival[]).slice();
}

export function getUpcoming(params: UpcomingParams = {}) {
  const { days = 45, region, tags } = params;
  const today = nowIST();
  const end = new Date(today.getTime() + days * 24 * 60 * 60 * 1000);

  const items = getAll()
    .map(f => ({ ...f, _date: toDateISO(f.date_iso) }))
    .filter(f => f._date >= today && f._date <= end)
    .filter(f => !region || (f.region || "IN").toLowerCase().startsWith(region.toLowerCase()))
    .filter(f => !tags?.length || (f.tags || []).every(t => tags.includes(t)))
    .sort((a, b) => a._date.getTime() - b._date.getTime());

  return items;
}

export function getFeatured(limit = 8) {
  return getAll()
    .map(f => ({ ...f, _date: toDateISO(f.date_iso) }))
    .filter(f => f.featured)
    .sort((a, b) => a._date.getTime() - b._date.getTime())
    .slice(0, limit);
}

export function sectionize() {
  const today = nowIST();
  const week = getUpcoming({ days: 7 });
  const month = getUpcoming({ days: 30 });
  const nextMonth = getUpcoming({ days: 60 }).filter(
    f => f._date.getTime() > month[month.length - 1]?._date.getTime()
  );
  const featured = getFeatured();
  return { today, week, month, nextMonth, featured, todayISO: today.toISOString() };
}
