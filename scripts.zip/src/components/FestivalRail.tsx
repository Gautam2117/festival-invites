// src/components/FestivalRail.tsx
import Link from "next/link";
import Image from "next/image";
import { sectionize } from "@/lib/festivals";
import type { Festival } from "@/types/festival";

/* ----------------------------- date utilities ----------------------------- */
const IST = "Asia/Kolkata";

function daysUntilISO(iso: string): { label: string; days: number } {
  const fmt = new Intl.DateTimeFormat("en-GB", {
    timeZone: IST,
    year: "numeric",
    month: "2-digit",
    day: "2-digit",
  });

  const partsNow = fmt.formatToParts(new Date());
  const yNow = Number(partsNow.find(p => p.type === "year")?.value);
  const mNow = Number(partsNow.find(p => p.type === "month")?.value);
  const dNow = Number(partsNow.find(p => p.type === "day")?.value);
  const today = new Date(yNow, mNow - 1, dNow);

  const target = new Date(iso + "T00:00:00.000Z");
  const t = new Date(target.getUTCFullYear(), target.getUTCMonth(), target.getUTCDate());
  const diffMs = t.getTime() - today.getTime();
  const days = Math.round(diffMs / 86400000);

  let label = "";
  if (days === 0) label = "Today";
  else if (days === 1) label = "Tomorrow";
  else if (days > 1) label = `In ${days} days`;
  else label = `${Math.abs(days)} days ago`;

  return { label, days };
}

function whenLabel(iso: string) {
  const d = new Date(iso + "T00:00:00.000Z");
  return d.toLocaleDateString("en-IN", { day: "2-digit", month: "short", year: "numeric" });
}

/* --------------------------------- Card ---------------------------------- */
type CardProps = Pick<Festival, "slug" | "name" | "date_iso" | "hero_image" | "region">;

function Card(p: CardProps) {
  const { label: relative, days } = daysUntilISO(p.date_iso);
  const when = whenLabel(p.date_iso);
  const region = p.region || "IN";
  const href = `/builder?festival=${encodeURIComponent(p.slug)}`;

  return (
    <Link
      href={href}
      aria-label={`Create invite for ${p.name} on ${when}`}
      prefetch
      className="group relative overflow-hidden rounded-xl border border-white/70 bg-white/80 p-3 shadow-sm backdrop-blur transition hover:shadow-md"
    >
      <div className="relative mb-2 h-28 w-full overflow-hidden rounded-lg">
        {p.hero_image ? (
          <Image
            src={p.hero_image}
            alt={p.name}
            fill
            sizes="(max-width:768px) 100vw, (max-width:1200px) 33vw, 20vw"
            className="object-cover transition-transform duration-300 group-hover:scale-[1.03]"
            priority={days <= 7}
          />
        ) : (
          <div className="absolute inset-0 bg-gradient-to-br from-amber-200 to-rose-200" />
        )}
        <div className="pointer-events-none absolute right-2 top-2 rounded-full bg-black/65 px-2 py-0.5 text-[10px] font-medium text-white shadow-sm">
          {relative}
        </div>
      </div>

      <div className="text-[11px] text-zinc-500">{when}</div>
      <div className="line-clamp-1 text-sm font-semibold">{p.name}</div>

      <div className="mt-2 flex items-center justify-between">
        <span className="rounded-md bg-emerald-50 px-2 py-0.5 text-[11px] text-emerald-700 ring-1 ring-emerald-200">
          Create invite
        </span>
        <span className="rounded-md bg-zinc-100 px-1.5 py-0.5 text-[10px] text-zinc-600 ring-1 ring-zinc-200">
          {region}
        </span>
      </div>
    </Link>
  );
}

/* ------------------------------- Section UI ------------------------------- */
function Section({
  title,
  items,
  testId,
}: {
  title: string;
  items: CardProps[];
  testId: string;
}) {
  if (!items.length) return null;
  return (
    <section className="mt-8 first:mt-0" data-testid={testId}>
      <h2 className="text-base font-semibold tracking-tight md:text-lg">{title}</h2>
      <div className="mt-3 grid grid-cols-2 gap-3 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5">
        {items.map((f) => (
          <Card
            key={f.slug}
            slug={f.slug}
            name={f.name}
            date_iso={f.date_iso}
            hero_image={f.hero_image}
            region={f.region}
          />
        ))}
      </div>
    </section>
  );
}

/* --------------------------------- Rail ---------------------------------- */
export default async function FestivalRail() {
  const { featured, week, nextMonth } = sectionize();

  if (!featured.length && !week.length && !nextMonth.length) return null;

  const slim = (arr: Festival[]) =>
    arr.map((f) => ({
      slug: f.slug,
      name: f.name,
      date_iso: f.date_iso,
      hero_image: f.hero_image,
      region: f.region,
    }));

  return (
    <div className="mx-auto max-w-6xl px-4 py-8">
      <Section title="Featured festivals" items={slim(featured)} testId="rail-featured" />
      <Section title="This week" items={slim(week)} testId="rail-week" />
      <Section title="Next month" items={slim(nextMonth)} testId="rail-next-month" />
    </div>
  );
}
