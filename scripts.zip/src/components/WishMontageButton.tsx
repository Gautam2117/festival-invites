// src/components/WishMontageButton.tsx
"use client";
import { useState } from "react";

function download(url: string, name: string) {
  const a = document.createElement("a");
  a.href = url;
  a.download = name;
  document.body.appendChild(a);
  a.click();
  a.remove();
}

export default function WishMontageButton({ inviteId }: { inviteId: string }) {
  const [busy, setBusy] = useState(false);
  const [lastUrl, setLastUrl] = useState<string | null>(null);

  async function create() {
    setBusy(true);
    try {
      const r = await fetch(`/api/montage/wishes/${inviteId}?count=6&seconds=12`);
      const j = await r.json();
      if (!r.ok) throw new Error(j?.error || "Failed");
      setLastUrl(j.url);
      download(j.url, "wishboard-status.mp4");
      // try native share (best for WhatsApp Status)
      if (navigator.share) {
        try {
          const resp = await fetch(j.url);
          const blob = await resp.blob();
          const file = new File([blob], "wishboard-status.mp4", { type: "video/mp4" });
          if (navigator.canShare?.({ files: [file] })) {
            await navigator.share({
              files: [file],
              title: "Wishboard Status",
              text: "Post to your WhatsApp Status 🎉",
            });
          }
        } catch { /* ignore */ }
      }
    } catch (e: any) {
      alert(e?.message || "Failed to create montage");
    } finally {
      setBusy(false);
    }
  }

  return (
    <button
      onClick={create}
      disabled={busy}
      className="rounded-lg border px-4 py-2 text-sm font-medium hover:bg-zinc-50 disabled:opacity-60"
      title="Compile top wishes into a short status video"
    >
      {busy ? "Compiling…" : "Create Wish Status"}
    </button>
  );
}
