"use client";
import { useState } from "react";
import { PLANS } from "@/constants/pricing";
import { createOrder, openCheckout } from "@/lib/pay";
import { usePlan } from "@/context/PlanContext";

export default function UpgradeModal({ inviteId, onClose, onUpgraded }:{
  inviteId: string; onClose: ()=>void; onUpgraded: (planId: keyof typeof PLANS)=>void;
}) {
  const [busy, setBusy] = useState<string | null>(null);
  const [err, setErr] = useState<string | null>(null);
  const { setLocal, tiers } = usePlan();

  async function buy(planId: keyof typeof PLANS) {
    setErr(null); setBusy(planId);
    try {
      const order = await createOrder(planId, inviteId);
      await openCheckout({
        orderId: order.id,
        name: "Festival Invites",
        description: PLANS[planId].label,
        onSuccess: async (payload) => {
          const vr = await fetch("/api/payments/verify", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(payload),
          });
          const j = await vr.json();
          if (!vr.ok) throw new Error(j?.error || "Verify failed");
          // update local entitlements
          const next = Array.from(new Set([...(tiers || []), planId]));
          setLocal(next as any);
          onUpgraded(planId);
          onClose();
        },
        onFailure: (e) => setErr(String(e?.message || "Payment failed"))
      });
    } catch (e:any) {
      setErr(e.message || "Failed to start payment");
    } finally {
      setBusy(null);
    }
  }

  return (
    <div className="fixed inset-0 z-50 grid place-items-center bg-black/40 p-4">
      <div className="w-full max-w-md rounded-2xl bg-white p-5 shadow-xl dark:bg-zinc-900">
        <div className="mb-3 text-lg font-semibold">Unlock premium</div>
        <div className="space-y-2 text-sm">
          <button disabled={!!busy} onClick={() => buy("image_hd")}
            className="w-full rounded-lg border p-3 text-left hover:bg-zinc-50 disabled:opacity-60">
            <div className="flex items-center justify-between">
              <div>
                <div className="font-medium">HD Image</div>
                <div className="text-xs text-zinc-600">1080p, no watermark</div>
              </div>
              <div>₹29</div>
            </div>
          </button>

          <button disabled={!!busy} onClick={() => buy("video_hd")}
            className="w-full rounded-lg border p-3 text-left hover:bg-zinc-50 disabled:opacity-60">
            <div className="flex items-center justify-between">
              <div>
                <div className="font-medium">HD Video</div>
                <div className="text-xs text-zinc-600">1080x1920, no watermark</div>
              </div>
              <div>₹79</div>
            </div>
          </button>

          <button disabled={!!busy} onClick={() => buy("brand_kit")}
            className="w-full rounded-lg border p-3 text-left hover:bg-zinc-50 disabled:opacity-60">
            <div className="flex items-center justify-between">
              <div>
                <div className="font-medium">Brand Kit</div>
                <div className="text-xs text-zinc-600">Logo + colors + end card</div>
              </div>
              <div>₹149</div>
            </div>
          </button>

          <button disabled={!!busy} onClick={() => buy("season_pass")}
            className="w-full rounded-lg border p-3 text-left hover:bg-zinc-50 disabled:opacity-60">
            <div className="flex items-center justify-between">
              <div>
                <div className="font-medium">Season Pass</div>
                <div className="text-xs text-zinc-600">Unlimited HD images + 20 videos</div>
              </div>
              <div>₹199</div>
            </div>
          </button>
        </div>

        {err && <p className="mt-3 text-xs text-red-600">{err}</p>}

        <div className="mt-4 flex justify-end gap-2">
          <button onClick={onClose} className="rounded-lg border px-3 py-1.5 text-sm">Close</button>
        </div>
      </div>
    </div>
  );
}
