"use client";
import { useState } from "react";

export default function WishForm({ inviteId }: { inviteId: string }) {
  const [senderType, setSenderType] = useState<"company"|"family"|"personal">("personal");
  const [senderName, setSenderName] = useState("");
  const [message, setMessage] = useState("");
  const [logoUrl, setLogoUrl] = useState("");
  const [busy, setBusy] = useState(false);
  const [ok, setOk] = useState<null | { approved: boolean }>(null);
  const [err, setErr] = useState<string | null>(null);

  async function onSubmit(e: React.FormEvent) {
    e.preventDefault();
    setErr(null);
    setOk(null);
    if (!message.trim()) return setErr("Please write a message.");
    setBusy(true);
    try {
      const res = await fetch(`/api/wishes/${inviteId}`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          message,
          senderName,
          senderType,
          logoUrl: senderType === "company" && logoUrl ? logoUrl : null,
        }),
      });
      const j = await res.json();
      if (!res.ok) throw new Error(j?.error || "Failed");
      setOk({ approved: !!j.approved });
      setMessage("");
      // keep name/type for convenience
      // 🔔 notify the list to refresh
      window.dispatchEvent(new CustomEvent("wish:submitted"));
    } catch (e: any) {
      setErr(e.message || "Failed");
    } finally {
      setBusy(false);
    }
  }

  return (
    <form onSubmit={onSubmit} className="rounded-xl border bg-white/60 p-4 shadow-sm dark:bg-zinc-900/50">
      <div className="grid gap-3">
        <div className="grid grid-cols-3 gap-2 text-sm">
          {(["personal","family","company"] as const).map(t => (
            <label
              key={t}
              className={
                "flex items-center gap-2 rounded-lg border px-2 py-1.5 " +
                (senderType===t ? "bg-emerald-50 ring-1 ring-emerald-200" : "")
              }>
              <input type="radio" name="senderType" value={t} checked={senderType===t} onChange={()=>setSenderType(t)} />
              {t[0].toUpperCase()+t.slice(1)}
            </label>
          ))}
        </div>

        <input
          className="rounded-lg border px-3 py-2 text-sm outline-none focus:ring-2 focus:ring-emerald-300"
          placeholder="Your name or family/company name (optional)"
          value={senderName} onChange={e=>setSenderName(e.target.value)} maxLength={60}
        />

        {senderType==="company" && (
          <input
            className="rounded-lg border px-3 py-2 text-sm outline-none focus:ring-2 focus:ring-emerald-300"
            placeholder="Logo URL (optional, https only)"
            value={logoUrl} onChange={e=>setLogoUrl(e.target.value)}
          />
        )}

        <textarea
          className="min-h-[96px] rounded-lg border px-3 py-2 text-sm outline-none focus:ring-2 focus:ring-emerald-300"
          placeholder="Write your wish... (max 240 characters)"
          value={message} onChange={e=>setMessage(e.target.value)} maxLength={240}
        />

        <div className="flex items-center justify-between">
          <div className="text-xs text-zinc-500">{message.length}/240</div>
          <button disabled={busy} className="rounded-lg bg-emerald-600 px-4 py-2 text-sm font-medium text-white hover:bg-emerald-700 disabled:opacity-60">
            {busy ? "Sending..." : "Send wish"}
          </button>
        </div>

        {ok && (
          <p className="text-xs text-emerald-700">
            {ok.approved ? "Wish posted." : "Thanks! Your wish is submitted and will appear after review."}
          </p>
        )}
        {err && <p className="text-xs text-red-600">{err}</p>}
        <p className="text-[11px] text-zinc-500">Cooldown: 60s per invite.</p>
      </div>
    </form>
  );
}
