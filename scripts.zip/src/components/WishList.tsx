"use client";
import { useEffect, useState } from "react";
import WishCard from "./WishCard";

export default function WishList({ inviteId }: { inviteId: string }) {
  const [items, setItems] = useState<any[]>([]);
  const [after, setAfter] = useState<number>(0);
  const [loading, setLoading] = useState(false);
  const [done, setDone] = useState(false);

  async function loadMore(reset = false) {
    if (loading || (done && !reset)) return;
    setLoading(true);

    const cursor = reset ? 0 : after;
    const r = await fetch(`/api/wishes/${inviteId}` + (cursor ? `?after=${cursor}` : ""));
    const j = await r.json();
    const next = j.items || [];

    setItems(prev => reset ? next : [...prev, ...next]);
    if (next.length === 0 || next.length < 100) setDone(true);

    const last = next[next.length - 1];
    setAfter(last ? last.createdAt : cursor);
    setLoading(false);
  }

  useEffect(() => {
    // initial load and when invite changes
    setItems([]); setAfter(0); setDone(false);
    loadMore(true);
    // refresh after new submission
    const onSubmitted = () => { setDone(false); loadMore(true); };
    window.addEventListener("wish:submitted", onSubmitted);
    return () => window.removeEventListener("wish:submitted", onSubmitted);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [inviteId]);

  return (
    <div className="mt-4 space-y-3">
      {items.length === 0 && !loading && <div className="text-sm text-zinc-500">No wishes yet.</div>}
      {items.map(w => <WishCard key={w.id} {...w} />)}
      {!done && (
        <div className="flex justify-center">
          <button
            onClick={() => loadMore()}
            disabled={loading}
            className="mt-2 rounded-lg border px-3 py-1.5 text-sm hover:bg-zinc-50 disabled:opacity-60"
          >
            {loading ? "Loading..." : "Load more"}
          </button>
        </div>
      )}
    </div>
  );
}
