// src/components/ShareBar.tsx
"use client";
import { useCallback } from "react";

export default function ShareBar(props: { title: string; url: string }) {
  const { title, url } = props;

  const onNativeShare = useCallback(async () => {
    if ((navigator as any).share) {
      try {
        await (navigator as any).share({ title, url });
      } catch {}
    }
  }, [title, url]);

  const encoded = encodeURIComponent(`${title} ${url}`);
  const wa = `https://wa.me/?text=${encoded}`;
  const tg = `https://t.me/share/url?url=${encodeURIComponent(url)}&text=${encodeURIComponent(title)}`;
  const tw = `https://x.com/intent/tweet?text=${encoded}`;

  const base =
    "rounded-full px-3 py-1.5 text-sm font-medium ring-1 transition shadow-sm hover:opacity-95";

  return (
    <div className="flex flex-wrap items-center gap-2">
      <button
        onClick={onNativeShare}
        className={`${base} bg-gradient-to-tr from-indigo-600 to-violet-600 text-white ring-indigo-300`}
        aria-label="Share"
      >
        Share
      </button>

      <a className={`${base} bg-emerald-50 text-emerald-700 ring-emerald-200`} href={wa} target="_blank" rel="noreferrer">
        WhatsApp
      </a>
      <a className={`${base} bg-sky-50 text-sky-700 ring-sky-200`} href={tg} target="_blank" rel="noreferrer">
        Telegram
      </a>
      <a className={`${base} bg-zinc-100 text-zinc-700 ring-zinc-200`} href={tw} target="_blank" rel="noreferrer">
        X
      </a>

      <button
        onClick={() => navigator.clipboard?.writeText(url)}
        className={`${base} bg-white text-zinc-900 ring-zinc-200`}
        aria-label="Copy link"
      >
        Copy link
      </button>
    </div>
  );
}
