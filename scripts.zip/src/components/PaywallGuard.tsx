"use client";
import { useState } from "react";
import { usePlan } from "@/context/PlanContext";
import UpgradeModal from "./UpgradeModal";

export default function PaywallGuard({
  inviteId,
  need,                 // "image_hd" | "video_hd" | "brand_kit"
  children,
  onUpgraded,
}: {
  inviteId: string;
  need: "image_hd" | "video_hd" | "brand_kit";
  children: (unlock: () => void, locked: boolean) => React.ReactNode;
  onUpgraded?: () => void;
}) {
  const { has } = usePlan();
  const [open, setOpen] = useState(false);

  const locked = !has(need);
  function unlock() {
    if (locked) setOpen(true);
  }

  return (
    <>
      {children(unlock, locked)}
      {open && (
        <UpgradeModal
          inviteId={inviteId}
          onClose={() => setOpen(false)}
          onUpgraded={() => { setOpen(false); onUpgraded?.(); }}
        />
      )}
    </>
  );
}
