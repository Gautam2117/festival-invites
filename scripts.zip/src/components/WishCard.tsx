export default function WishCard(props: {
  message: string; senderName?: string; senderType: string; logoUrl?: string | null; createdAt: number;
}) {
  const { message, senderName, senderType, logoUrl, createdAt } = props;
  const when = new Date(createdAt).toLocaleString("en-IN", { hour12: true });
  const badge = senderType === "company" ? "Company" : senderType === "family" ? "Family" : "Personal";

  return (
    <div className="rounded-xl border bg-white/60 p-4 shadow-sm dark:bg-zinc-900/50">
      <div className="flex items-center justify-between gap-3">
        <div className="text-xs text-zinc-500">{when}</div>
        <span className="rounded-full bg-emerald-50 px-2.5 py-0.5 text-xs text-emerald-700 ring-1 ring-emerald-200 dark:bg-emerald-900/30 dark:text-emerald-300">
          {badge}
        </span>
      </div>
      <p className="mt-3 text-sm leading-relaxed">{message}</p>
      <div className="mt-3 flex items-center gap-3">
        {logoUrl ? <img src={logoUrl} alt="logo" className="h-6 w-6 rounded object-cover ring-1 ring-zinc-200" /> : null}
        {senderName ? <div className="text-xs text-zinc-600">— {senderName}</div> : null}
      </div>
    </div>
  );
}
