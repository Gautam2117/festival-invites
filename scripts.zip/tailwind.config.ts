// tailwind.config.ts (minimal; optional)
import type { Config } from "tailwindcss";
const config: Config = {
  content: ["./src/**/*.{ts,tsx}"],
};
export default config;
